Sys.setenv("VROOM_CONNECTION_SIZE"=131072*6)
library(readxl)
library(tidyverse)
library(GEOquery)
library(tidyverse)
library(limma)



exp <- read.table(file = "GSE157103_genes.tpm.tsv.gz",sep = "\t")

pd <- read.table(file = "GSE157103注释.txt",sep = "\t")
x <- pd[18,]
x1 <- t(x)  
x1[1] <- "gene"
colnames(exp) <- x1
exp <- column_to_rownames(exp,"gene")
exp <- log2(exp+1)#TPM数据要先log2(x+1)后才能limma

pd_clean <-read.table(file = "GSE157103清洁临床信息.txt") 
covid_pd_clean <- pd_clean[1:100,]



#是否入住icu分组----
pd_icu <- arrange(covid_pd_clean,icu)
table(pd_icu$icu)

exp_icu <- exp[,rownames(pd_icu),drop=F]

list <- c(rep("noicu", 50), rep("icu",50)) %>% factor(., levels = c("noicu", "icu"), ordered = F)
head(list)
list <- model.matrix(~factor(list)+0) 
colnames(list) <- c("noicu","icu")
df.fit <- lmFit(exp_icu, list)
df.matrix <- makeContrasts(icu - noicu , levels = list)#COVID组比Control组，COVID写前面
fit <- contrasts.fit(df.fit, df.matrix)
fit <- eBayes(fit)
tempOutput <- topTable(fit,n = Inf, adjust = "fdr")
nrDEG = na.omit(tempOutput) ## 去掉数据中有NA的行或列
diffsig <- nrDEG
foldChange = 1
padj = 0.05
## 筛选出所有差异基因的结果
All_diffSig <- diffsig[(diffsig$adj.P.Val < padj & (diffsig$logFC>foldChange | diffsig$logFC < (-foldChange))),]
dim(All_diffSig)
#筛选上下调基因
diffup <-  All_diffSig[(All_diffSig$P.Value < padj & (All_diffSig$logFC > foldChange)),]

#
diffdown <- All_diffSig[(All_diffSig$P.Value < padj & (All_diffSig < -foldChange)),]
diffdown <- na.omit(diffdown)
diff <- rbind(diffup,diffdown)
write.table(diff,file = "icu.diff.txt",sep = "\t")
#是否机械通气分组----

pd_mechine <- arrange(covid_pd_clean,mechanical.ventilation)
table(pd_mechine$mechanical.ventilation)

exp_mechine <- exp[,rownames(pd_mechine),drop=F]

list <- c(rep("nomechine", 58), rep("mechine",42)) %>% factor(., levels = c("nomechine", "mechine"), ordered = F)
head(list)
list <- model.matrix(~factor(list)+0) 
colnames(list) <- c("nomechine","mechine")
df.fit <- lmFit(exp_mechine, list)
df.matrix <- makeContrasts(mechine - nomechine , levels = list)#COVID组比Control组，COVID写前面
fit <- contrasts.fit(df.fit, df.matrix)
fit <- eBayes(fit)
tempOutput <- topTable(fit,n = Inf, adjust = "fdr")
nrDEG = na.omit(tempOutput) ## 去掉数据中有NA的行或列
diffsig <- nrDEG
foldChange = 1
padj = 0.05
## 筛选出所有差异基因的结果
All_diffSig <- diffsig[(diffsig$adj.P.Val < padj & (diffsig$logFC>foldChange | diffsig$logFC < (-foldChange))),]
dim(All_diffSig)
#筛选上下调基因
diffup <-  All_diffSig[(All_diffSig$P.Value < padj & (All_diffSig$logFC > foldChange)),]

#
diffdown <- All_diffSig[(All_diffSig$P.Value < padj & (All_diffSig < -foldChange)),]
diffdown <- na.omit(diffdown)
diff <- rbind(diffup,diffdown)
write.table(diff,file = "mechine.diff.txt",sep = "\t")


####糖尿病分组----
pd_DM <- arrange(covid_pd_clean,DM)
pd_DM <- pd_DM[1:99,]
table(pd_DM$DM)

exp_DM <- exp[,rownames(pd_DM),drop=F]

list <- c(rep("noDM", 64), rep("DM",35)) %>% factor(., levels = c("noDM", "DM"), ordered = F)
head(list)
list <- model.matrix(~factor(list)+0) 
colnames(list) <- c("noDM","DM")
df.fit <- lmFit(exp_DM, list)
df.matrix <- makeContrasts(DM - noDM , levels = list)#COVID组比Control组，COVID写前面
fit <- contrasts.fit(df.fit, df.matrix)
fit <- eBayes(fit)
tempOutput <- topTable(fit,n = Inf, adjust = "fdr")
nrDEG = na.omit(tempOutput) ## 去掉数据中有NA的行或列
diffsig <- nrDEG
foldChange = 0.5
padj = 0.05
## 筛选出所有差异基因的结果
All_diffSig <- diffsig[(diffsig$adj.P.Val < padj & (diffsig$logFC>foldChange | diffsig$logFC < (-foldChange))),]
dim(All_diffSig)
#筛选上下调基因
diffup <-  All_diffSig[(All_diffSig$P.Value < padj & (All_diffSig$logFC > foldChange)),]

#
diffdown <- All_diffSig[(All_diffSig$P.Value < padj & (All_diffSig < -foldChange)),]
diffdown <- na.omit(diffdown)
diff <- rbind(diffup,diffdown)
write.table(diff,file = "DM.diff.txt",sep = "\t")



####H45----

pd_H <- arrange(covid_pd_clean,H45)
table(pd_H$H45)

exp_H <- exp[,rownames(pd_H),drop=F]

list <- c(rep("未出院", 29), rep("出院",71)) %>% factor(., levels = c("未出院", "出院"), ordered = F)
head(list)
list <- model.matrix(~factor(list)+0) 
colnames(list) <- c("未出院","出院")
df.fit <- lmFit(exp_H, list)
df.matrix <- makeContrasts(未出院 - 出院 , levels = list)#COVID组比Control组，COVID写前面
fit <- contrasts.fit(df.fit, df.matrix)
fit <- eBayes(fit)
tempOutput <- topTable(fit,n = Inf, adjust = "fdr")
nrDEG = na.omit(tempOutput) ## 去掉数据中有NA的行或列
diffsig <- nrDEG
foldChange = 1
padj = 0.05
## 筛选出所有差异基因的结果
All_diffSig <- diffsig[(diffsig$adj.P.Val < padj & (diffsig$logFC>foldChange | diffsig$logFC < (-foldChange))),]
dim(All_diffSig)
#筛选上下调基因
diffup <-  All_diffSig[(All_diffSig$P.Value < padj & (All_diffSig$logFC > foldChange)),]

#
diffdown <- All_diffSig[(All_diffSig$P.Value < padj & (All_diffSig < -foldChange)),]
diffdown <- na.omit(diffdown)
diff <- rbind(diffup,diffdown)
write.table(diff,file = "是否出院.diff.txt",sep = "\t")





outcome <- read.csv(file = "不同结局指标差异基因.csv")











#可视化（火山图）----

rm(list=ls())
icu <- tempOutput

## 导入R包
library(ggplot2)
library(ggrepel)
##  绘制火山图
## 进行分类别

diffsig <- icu

foldChange <- 1
padj <- 0.05
logFC <- diffsig$logFC
deg.padj <- diffsig$adj.P.Val#原文中用的p,这里要改
data <- data.frame(logFC = logFC, padj = deg.padj)
diffsig$group[(diffsig$adj.P.Val > 0.05 | diffsig$adj.P.Val == "NA") | (diffsig$logFC < foldChange) & diffsig$logFC > -foldChange] <- "Not"
diffsig$group[(diffsig$adj.P.Val <= 0.05 & diffsig$logFC > 1)] <-  "Up"
diffsig$group[(diffsig$adj.P.Val <= 0.05 & data$logFC < -1)] <- "Down"
x_lim <- max(logFC,-logFC)

# 开始绘图
pdf('volcano.pdf',width = 7,height = 6.5)  ## 输出文件
diffsig$label <- ifelse(diffsig$adj.P.Val< padj & abs(diffsig$logFC) >=1.5,
                        as.character(diffsig$Gene.symbol), "")#设置标签基因范围


ggplot(diffsig, aes(logFC, -log10(adj.P.Val)))+#建立横纵坐标
  geom_point(aes(col=group))+#建造点图
  scale_color_manual(values=c("#0072B5","grey","#BC3C28"))+#改变点颜色
  labs(title = "mechanical.ventilation")+#加标题备注
  geom_vline(xintercept=c(-1,1), colour="black", linetype="dashed")+#加线
  geom_hline(yintercept = -log10(0.05),colour="black", linetype="dashed")+
  theme(plot.title = element_text(size = 16, hjust = 0.5, face = "bold"))+
  labs(x="log2(FoldChange)",y="-log10(Pvalue)")+
  theme(axis.text=element_text(size=13),axis.title=element_text(size=13))+
  #str(diffsig, max.level = c(-1, 1))+theme_bw()+
  geom_label_repel(data = diffsig, aes(x = diffsig$logFC, 
                                       y = -log10(diffsig$adj.P.Val), 
                                       label = label),
                   size = 3, box.padding = unit(0.5, "lines"),
                   point.padding = unit(0.8, "lines"), 
                   segment.color = "black", 
                   show.legend = FALSE)
dev.off()




















