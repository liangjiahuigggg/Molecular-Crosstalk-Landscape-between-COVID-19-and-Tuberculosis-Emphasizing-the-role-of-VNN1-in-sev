Sys.setenv("VROOM_CONNECTION_SIZE"=131072*6)
library(readxl)
library(tidyverse)
library(GEOquery)
library(tidyverse)
library(limma)



exp <- read.table(file = "GSE157103_genes.tpm.tsv.gz",sep = "\t")

pd <- read.table(file = "GSE157103注释.txt",sep = "\t")
x <- pd[18,]
x1 <- t(x)  
x1[1] <- "gene"
colnames(exp) <- x1
exp <- column_to_rownames(exp,"gene")
exp <- log2(exp+1)#TPM数据要先log2(x+1)后才能limma


gene <- read.table(file = "TB_GSE157103_0.5共差异基因.txt")
colnames(gene) <- "gene"
g <- gene$gene
train <- exp[g,,drop=F]
train <- t(train)
train_group <- c(rep("COVID",100),rep("HC",26))
train <- as.data.frame(train)
train <- mutate(train,group=train_group)


test <- read.table(file = "GSE171110_exp.txt",sep = "\t")
test <- test[g,,drop=F]
test <- t(test)
test_group <- c(rep("HC",10),rep("COVID",44))
test <- as.data.frame(test)
test <- mutate(test,group=test_group)



####机器学习----

library(mlr3)#主体包
library(mlr3viz)#执行可视化功能
library(mlr3learners)#提供额外学习器
library(mlr3verse)#扩展包
library(mlr3tuning)
library(data.table)
library("magrittr")
#随机森林
lrn <- lrn("classif.ranger",importance = "impurity")#重要性筛选是需要基于学习器的
lrn$properties#查看学习器属性
task <- as_task_classif(train,target = "group",id = "rf",positive = "COVID")#拟合模型,设置"highrisk"为阳性结局
filter <- flt("importance",learner = lrn)#重要性筛选，基于随机森林学习器，根据基尼指数
filter$calculate(task)#拟合任务
head(as.data.table(filter),3)#查看结果
filter1 <-as.data.table(filter)
filter1 <- filter1[1:9,]#提取了大于1的9个
# redata <- data.frame(gene_name=gene_name,feature=gene_replace)
# f <- inner_join(filter1,redata,by="feature")
# f <- f[,-1]
library(ggplot2)
#ggplot(data=filter1)+geom_count(mapping = aes(x=feature,y=score,color=feature))
p <- ggplot(filter1,aes(reorder(feature,score),score))
p+geom_bar(stat = 'identity',aes(fill=feature))+coord_flip()+labs(x="Random Forest",y="Score")#可视化

RF<- as.data.table(filter)#查看打分结果
write.table(RF,file = "RF_score.txt",sep="\t",row.names = F)


RF_id <- filter1$feature
train <- train[,RF_id,drop=F]
train <- mutate(train,group=train_group)

test <- test[,RF_id,drop=F]
test <- mutate(test,group=test_group)

tasktrain <- as_task_classif(train,target = "group",postive="COVID",id="RF")
tasktest <- as_task_classif(test,target="group",positive = "COVID",id="valid")
lrn_rpart <-lrn("classif.ranger",predict_type="prob") 
lrn_rpart$param_set
#训练集自我验证
predtrain <- lrn_rpart$train(tasktrain)$predict(tasktrain)
predtrain$confusion
msr <- msrs("classif.auc")
predtrain$score(msr)
C=predtrain$confusion
print(C)
autoplot(predtrain,type = "roc")
#训练集的外部验证
predvalid <- lrn_rpart$train(tasktrain)$predict(tasktest)
predvalid$confusion
msr <- msrs("classif.auc")
predvalid$score(msr)
autoplot(predvalid,type = "roc")



#换学习器
lrn_rpart <-lrn("classif.svm",predict_type="prob") 

####线性模型----
library(foreign)#读入外部数据的包
library(rms)#执行算法的工具包
train$group <- stringr::str_replace(train$group,"COVID","1")
train$group <- stringr::str_replace(train$group,"HC","0")

test$group <- stringr::str_replace(test$group,"COVID","1")
test$group <- stringr::str_replace(test$group,"HC","0")

train_id <- rownames(train)
test_id <- rownames(test)

train <- as.data.frame(lapply(train,as.numeric))
test <- as.data.frame(lapply(test,as.numeric))


rownames(train) <- train_id
rownames(test) <- test_id


fit.full <- lm(group ~ GMNN + SCD + FUT7 + EPSTI1 + 
                 OASL + NCOA7 + FRMD3 +HNRNPLL+APP,
                data=train)
summary(fit.full)

fit.reduce <- lm(group ~ GMNN + FUT7 +OASL+NCOA7,
                 data=train)

coefficients(fit.reduce)#获取模型系数






library(pROC)
#GMNN的ROC----
aucTrain1 <- roc(group~GMNN,data=train,smooth=FALSE)
plot(aucTrain1,print.auc=T)
aucTest1 <- roc(group~GMNN,data=test,smooth=FALSE)
plot(aucTest1,print.auc=T)

#SCD
aucTrain1 <- roc(group~SCD,data=train,smooth=FALSE)
plot(aucTrain1,print.auc=T)
aucTest1 <- roc(group~SCD,data=test,smooth=FALSE)
plot(aucTest1,print.auc=T)

#FUT7
aucTrain1 <- roc(group~FUT7,data=train,smooth=FALSE)
plot(aucTrain1,print.auc=T)
aucTest1 <- roc(group~FUT7,data=test,smooth=FALSE)
plot(aucTest1,print.auc=T)
#EPSTI1
aucTrain1 <- roc(group~EPSTI1,data=train,smooth=FALSE)
plot(aucTrain1,print.auc=T)
aucTest1 <- roc(group~EPSTI1,data=test,smooth=FALSE)
plot(aucTest1,print.auc=T)
#OASL
aucTrain1 <- roc(group~OASL,data=train,smooth=FALSE)
plot(aucTrain1,print.auc=T)
aucTest1 <- roc(group~OASL,data=test,smooth=FALSE)
plot(aucTest1,print.auc=T)
#NCOA7
aucTrain1 <- roc(group~NCOA7,data=train,smooth=FALSE)
plot(aucTrain1,print.auc=T)
aucTest1 <- roc(group~NCOA7,data=test,smooth=FALSE)
plot(aucTest1,print.auc=T)
#FRMD3
aucTrain1 <- roc(group~FRMD3,data=train,smooth=FALSE)
plot(aucTrain1,print.auc=T)
aucTest1 <- roc(group~FRMD3,data=test,smooth=FALSE)
plot(aucTest1,print.auc=T)
#HNRNPLL
aucTrain1 <- roc(group~HNRNPLL,data=train,smooth=FALSE)
plot(aucTrain1,print.auc=T)
aucTest1 <- roc(group~HNRNPLL,data=test,smooth=FALSE)
plot(aucTest1,print.auc=T)
#APP
aucTrain1 <- roc(group~APP,data=train,smooth=FALSE)
plot(aucTrain1,print.auc=T)
aucTest1 <- roc(group~APP,data=test,smooth=FALSE)
plot(aucTest1,print.auc=T)

train$prob <- predict(fit.reduce, newdata=train, type="response")
test$prob <- predict(fit.reduce, newdata=test, type="response")

aucTrain <- roc(group~prob,data=train,smooth=FALSE)
plot(aucTrain,print.auc=T)
aucTest <- roc(group~prob,data=test,smooth=FALSE)
plot(aucTest,print.auc=T)



#取GMNN高低风险组----

GMNN <- filter(train,group==1)
GMNN <- arrange(GMNN,GMNN)
GMNN_group <- c(rep("GMNN-low",50),rep("GMNN-high",50))

GMNN <- mutate(GMNN,"GMNN分组"=GMNN_group)
GMNN_id <-rownames(GMNN) 
GMNN_type <- data.frame(ID=GMNN_id,"GMNN分组"=GMNN_group)
write.table(GMNN_type,file = "GMNN_type.txt",sep = "\t",row.names = F)



# d <- exp[x,,drop=F]
# d <- t(d)
# write.table(d,file = "5exp.txt",sep = "\t")





