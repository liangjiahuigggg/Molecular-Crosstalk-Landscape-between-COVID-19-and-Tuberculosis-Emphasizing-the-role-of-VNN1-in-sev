
#准备文件LM22.txt，DATA.txt，Cibersort.R
source('Cibersort.R')
result1 <- CIBERSORT('LM22.txt','DATA.txt', perm = 1000, QN = T)  #perm置换次数=1000，QN分位数归一化=TRUE
write.table(result1,file = "cibersort.txt",sep = "\t")

data <- result1[,1:22]
data <- data[1:100,]

risk_score <-read.table(file = "VNN1-type.txt",header = T)#读取分组信息

group <- risk_score$group
data <- as.data.frame(data)
data <- mutate(data,"group"=group)#data和risk_socre样本顺序一样，直接添加了

#data <- t(data)


library(dplyr)
library(tibble)
library(tidyr)
library(ggplot2)
library(ggpubr)
library(ggsci)
res <- data%>%
  rownames_to_column("sample")%>%
  pivot_longer(cols = colnames(.)[2:23],
               names_to = "cell.type",
               values_to = 'value')


compaired <- list(c("low","high"))


#ggplot(res,aes(cell.type,value,fill = group)) + 
 # geom_boxplot(outlier.shape = 21,color = "black") + 
  #theme_bw() + 
  #labs(x = "Cell Type", y = "Estimated Proportion") +
  #theme(legend.position = "top") + 
  #theme(axis.text.x = element_text(angle=80,vjust = 0.5,size = 14,face = "italic",colour = 'black'),
   #     axis.text.y = element_text(face = "italic",size = 14,colour = 'black'))+
  #scale_fill_nejm()+#修改配色
  #stat_compare_means(
  #  comparisons = compaired,
  #  label = "p.signif",
  #  method = "t.test",
    #ref.group = ".all.",
   # hide.ns = T，
  #) 



#箱线图可视化
ggboxplot(
  res,
  x = "cell.type",
  y = "value",
  color = "black",
  fill = "group",
  xlab = "Cell Type",
  ylab = "Estimated Proportion",
  main = "CIBERSORT"
) +
  scale_fill_nejm()+
  stat_compare_means(
    label = "p.signif",
    method = "wilcox.test",#俩组用"wilcox.test"，多组用“kruskal.test
    ref.group = ".all.",
    hide.ns = T
  ) +
  #theme_base() +
  theme(axis.text.x = element_text(
    angle = 45,
    hjust = 0.5,
    vjust = 0.5
  ))#字体倾斜45°

#COR相关性
#很棒的参考链接https://zhuanlan.zhihu.com/p/407089870#:~:text=corrplot%20%28%29%E4%B8%AD%E7%9A%84%E5%8F%82%E6%95%B0add%3DTRUE%EF%BC%8C%E5%8F%AF%E7%94%A8%E4%BA%8E%E5%8F%A0%E5%8A%A0%E4%B8%8D%E5%90%8C%E5%8F%AF%E8%A7%86%E5%8C%96%E5%BD%A2%E5%BC%8F%E7%9A%84upper%E5%92%8Clower%E9%83%A8%E5%88%86%E3%80%82,corrplot.mixed%20%28%29%E5%87%BD%E6%95%B0%E5%88%99%E5%8F%AF%E4%BB%A5%E7%9B%B4%E6%8E%A5%E7%BB%98%E5%88%B6upper%E5%92%8Clower%E4%B8%8D%E5%90%8C%E6%95%B0%E6%8D%AE%E5%BD%A2%E5%BC%8F%E7%9A%84%E7%9F%A9%E5%BD%A2%E7%83%AD%E5%9B%BE%E3%80%82
library(Rmisc) 
library(corrplot)
library(ggcorrplot)
library(RColorBrewer)
library(grDevices)
data <- result1[,1:22]
cor.matrix <- round(cor(data),3)
cor.p <-round(cor_pmat(data,method = "pearson"),3)
corrplot(corr =cor.matrix, p.mat = cor.p)

corrplot(corr =cor.matrix, p.mat = cor.p,method = "number")
# 3.2.5 图中显著性p值展示形式。
m=par(no.readonly = TRUE) # 保存默认图形设置参数
pdf("insig.pdf",width = 12,height = 12) # 保存图片到本地
## corrplot()函数参数add=TRUE用于叠加

corrplot(corr =cor.matrix, p.mat = cor.p,method = "circle",type = "upper", tl.pos="lt",insig="label_sig",sig.level = c(.001, .01, .05),pch.cex = 0.8) # 用*作为显著性标签，sig.level参数表示0.05用*表示。0.01用**。0.001用***。pch.cex = 0.8,用于设置显著性标签的字符大小。
corrplot(corr = cor.matrix,type="lower",add=TRUE,method="number", tl.pos = "n",cl.pos = "n",diag=FALSE ) 
dev.off()

par(m) # 还原初始图形设置


#riskscore与22种细胞的cor相关性图
rm(list = ls())
library(limma)
library(reshape2)
library(ggpubr)
library(vioplot)
library(ggExtra)

result1 <- read.table(file = "cibersort.txt",check.names = F)
data <- result1[,1:22]
clinical <-read.table(file = "GSE157103清洁临床信息.txt",header = T)#读取分组信息
VF <- clinical$ventilator.free.days
data <- as.data.frame(data)
rt <- mutate(data,H45=H45)
rt <- rt[1:100,]

#spearma相关图
# for(i in colnames(rt)[1:(ncol(rt)-1)]){
#   x=as.numeric(rt[,"riskscore"])
#   y=as.numeric(rt[,i])
#   #if(sd(y)<0.01){next}
#   cor=cor.test(x, y, method="spearma",exact=FALSE)#出现报错“无法给连结计算精確p值”，添加exact=FALSE得到近似值
#   if(cor$p.value<0.05){
#     outFile=paste0("cor.", i, ".pdf")
#     df1=as.data.frame(cbind(x,y))
#     p1=ggplot(df1, aes(x, y)) +
#       xlab("Risk score") + ylab(i)+
#       geom_point() + geom_smooth(method="lm",formula = y ~ x) + theme_bw()+
#       stat_cor(method = 'spearman', aes(x =x, y =y))
#     p2=ggMarginal(p1, type="density", xparams=list(fill = "orange"), yparams=list(fill = "blue"))
# 
#     pdf(file=outFile, width=5.2, height=5)
#     print(p2)
#     dev.off()
#   }
# }




  
  
#Pearson相关图  (临床指标)
  
for(i in colnames(rt)[1:(ncol(rt)-1)]){
  x=as.numeric(rt[,"H45"])
  y=as.numeric(rt[,i])
  #if(sd(y)<0.01){next}
  cor=cor.test(x, y, method="pearson")
  if(cor$p.value<0.05){
    outFile=paste0("cor.", i, ".pdf")
    df1=as.data.frame(cbind(x,y))
    p1=ggplot(df1, aes(y, x)) +
      xlab(i) + ylab("H45")+
      geom_point() + geom_smooth(method="lm",formula = y ~ x) + theme_bw()+
      stat_cor(method = 'spearman', aes(x =x, y =y))
    p2=ggMarginal(p1, type="density", xparams=list(fill = "orange"), yparams=list(fill = "blue"))
    
    pdf(file=outFile, width=5.2, height=5)
    print(p2)
    dev.off()
  }
}
  

#Pearson相关图  VNN1与免疫

result1 <- read.table(file = "cibersort.txt",check.names = F)
data <- result1[,1:22] 
x <- read.table(file = "11exp.txt")
x <- t(x)
x <- as.data.frame(x)
VNN1 <- x$VNN1  
rt <- mutate(data,VNN1=VNN1)
rt <- rt[1:100,]
  
  
for(i in colnames(rt)[1:(ncol(rt)-1)]){
  x=as.numeric(rt[,"VNN1"])
  y=as.numeric(rt[,i])
  #if(sd(y)<0.01){next}
  cor=cor.test(x, y, method="spearman")
  if(cor$p.value<0.05){
    outFile=paste0("cor.", i, ".pdf")
    df1=as.data.frame(cbind(x,y))
    p1=ggplot(df1, aes(x, y)) +
      xlab("VNN1") + ylab(i)+
      geom_point() + geom_smooth(method="lm",formula = y ~ x) + theme_bw()+
      stat_cor(method = 'spearman', aes(x =x, y =y))
    p2=ggMarginal(p1, type="density", xparams=list(fill = "orange"), yparams=list(fill = "blue"))
    
    pdf(file=outFile, width=5.2, height=5)
    print(p2)
    dev.off()
  }
}


rt <- data.frame(H45=H45,ventilator_free_days=VF,VNN1=VNN1)
 

p1=ggplot(rt, aes(VNN1, H45)) +
  xlab("VNN1") + ylab("H45")+
  geom_point() + geom_smooth(method="lm",formula = y ~ x) + theme_bw()+
  stat_cor(method = 'spearman', aes(x =x, y =y))
p2=ggMarginal(p1, type="density", xparams=list(fill = "orange"), yparams=list(fill = "blue"))






