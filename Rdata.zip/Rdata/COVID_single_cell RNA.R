
#准备----
library(patchwork)
library(Seurat)
library(dplyr)
library(ggplot2)



SCOVID1 <- Read10X(data.dir = './SCOVID1//')
SCOVID2 <- Read10X(data.dir = './SCOVID2//')
SCOVID3 <- Read10X(data.dir = './SCOVID3//')
SCOVID4 <- Read10X(data.dir = './SCOVID4//')
SCOVID5 <- Read10X(data.dir = './SCOVID5//')
SCOVID6 <- Read10X(data.dir = './SCOVID6//')
SCOVID7 <- Read10X(data.dir = './SCOVID7//')
SCOVID8 <- Read10X(data.dir = './SCOVID8//')
SCOVID9 <- Read10X(data.dir = './SCOVID9//')
SCOVID10 <- Read10X(data.dir = './SCOVID10//')
SCOVID11 <- Read10X(data.dir = './SCOVID11//')
SCOVID12 <- Read10X(data.dir = './SCOVID12//')
SCOVID13 <- Read10X(data.dir = './SCOVID13//')
SCOVID14 <- Read10X(data.dir = './SCOVID14//')
SCOVID15 <- Read10X(data.dir = './SCOVID15//')
SCOVID16 <- Read10X(data.dir = './SCOVID16//')
SCOVID17 <- Read10X(data.dir = './SCOVID17//')
SCOVID18 <- Read10X(data.dir = './SCOVID18//')
SCOVID19 <- Read10X(data.dir = './SCOVID19//')
SCOVID20 <- Read10X(data.dir = './SCOVID20//')
Contral1 <- Read10X(data.dir = './Contral1//')
Contral2 <- Read10X(data.dir = './Contral2//')
Contral3 <- Read10X(data.dir = './Contral3//')
Contral4 <- Read10X(data.dir = './Contral4//')
Contral5 <- Read10X(data.dir = './Contral5//')
Contral6 <- Read10X(data.dir = './Contral6//')




scRNA1 <- CreateSeuratObject(counts = SCOVID1, project = "SCOVID1",min.cells = 3,min.features = 200)
scRNA2 <- CreateSeuratObject(counts = SCOVID2, project = "SCOVID2",min.cells = 3,min.features = 200)
scRNA3 <- CreateSeuratObject(counts = SCOVID3, project = "SCOVID3",min.cells = 3,min.features = 200)
scRNA4 <- CreateSeuratObject(counts = SCOVID4, project = "SCOVID4",min.cells = 3,min.features = 200)
scRNA5 <- CreateSeuratObject(counts = SCOVID5, project = "SCOVID5",min.cells = 3,min.features = 200)
scRNA6 <- CreateSeuratObject(counts = SCOVID6, project = "SCOVID6",min.cells = 3,min.features = 200)
scRNA7 <- CreateSeuratObject(counts = SCOVID7, project = "SCOVID7",min.cells = 3,min.features = 200)
scRNA8 <- CreateSeuratObject(counts = SCOVID8, project = "SCOVID8",min.cells = 3,min.features = 200)
scRNA9 <- CreateSeuratObject(counts = SCOVID9, project = "SCOVID9",min.cells = 3,min.features = 200)
scRNA10 <- CreateSeuratObject(counts = SCOVID10, project = "SCOVID10",min.cells = 3,min.features = 200)
scRNA11 <- CreateSeuratObject(counts = SCOVID11, project = "SCOVID11",min.cells = 3,min.features = 200)
scRNA12 <- CreateSeuratObject(counts = SCOVID12, project = "SCOVID12",min.cells = 3,min.features = 200)
scRNA13 <- CreateSeuratObject(counts = SCOVID13, project = "SCOVID13",min.cells = 3,min.features = 200)
scRNA14 <- CreateSeuratObject(counts = SCOVID14, project = "SCOVID14",min.cells = 3,min.features = 200)
scRNA15 <- CreateSeuratObject(counts = SCOVID15, project = "SCOVID15",min.cells = 3,min.features = 200)
scRNA16 <- CreateSeuratObject(counts = SCOVID16, project = "SCOVID16",min.cells = 3,min.features = 200)
scRNA17 <- CreateSeuratObject(counts = SCOVID17, project = "SCOVID17",min.cells = 3,min.features = 200)
scRNA18 <- CreateSeuratObject(counts = SCOVID18, project = "SCOVID18",min.cells = 3,min.features = 200)
scRNA19 <- CreateSeuratObject(counts = SCOVID19, project = "SCOVID19",min.cells = 3,min.features = 200)
scRNA20 <- CreateSeuratObject(counts = SCOVID20, project = "SCOVID20",min.cells = 3,min.features = 200)
scRNA21 <- CreateSeuratObject(counts = Contral1, project = "Contral1",min.cells = 3,min.features = 200)
scRNA22 <- CreateSeuratObject(counts = Contral2, project = "Contral2",min.cells = 3,min.features = 200)
scRNA23 <- CreateSeuratObject(counts = Contral3, project = "Contral3",min.cells = 3,min.features = 200)
scRNA24 <- CreateSeuratObject(counts = Contral4, project = "Contral4",min.cells = 3,min.features = 200)
scRNA25 <- CreateSeuratObject(counts = Contral5, project = "Contral5",min.cells = 3,min.features = 200)
scRNA26 <- CreateSeuratObject(counts = Contral6, project = "Contral6",min.cells = 3,min.features = 200)








sce.all = merge(scRNA1, y = c(scRNA2,scRNA3,scRNA4,scRNA5,scRNA6,scRNA7,scRNA8,scRNA9,scRNA10,
                              scRNA11,scRNA12,scRNA13,scRNA14,scRNA15,scRNA16,scRNA17,scRNA18,scRNA19,scRNA20,
                              scRNA21,scRNA22,scRNA23,scRNA24,scRNA25,scRNA26), add.cell.ids = c("SCOVID1", "SCOVID2","SCOVID3", "SCOVID4","SCOVID5", "SCOVID6","SCOVID7", "SCOVID8","SCOVID9", "SCOVID10","SCOVID11", "SCOVID12","SCOVID13", "SCOVID14","SCOVID15", "SCOVID16","SCOVID17", "SCOVID18","SCOVID19", "SCOVID20","Contral1", "Contral2","Contral3","Contral4", "Contral5","Contral6"),
                project = 'PR', merge.data = TRUE)
#metadata为样本信息，我们需要定义分组
sce.all@meta.data$patient=sce.all@meta.data$orig.ident
sce.all@meta.data$orig.ident=stringr::str_remove_all(sce.all@meta.data$orig.ident,'[0-9]')




rm(scRNA1,scRNA2,scRNA3,scRNA4,scRNA5,scRNA6,scRNA7,scRNA8,scRNA9,scRNA10,
   scRNA11,scRNA12,scRNA13,scRNA14,scRNA15,scRNA16,scRNA17,scRNA18,scRNA19,scRNA20,
   scRNA21,scRNA22,scRNA23,scRNA24,scRNA25,scRNA26)
rm(Contral1,Contral2,Contral3,Contral4,Contral5,Contral6)
rm(SCOVID1,SCOVID2,SCOVID3,SCOVID4,SCOVID5,SCOVID6,SCOVID7,SCOVID8,SCOVID9,SCOVID10,SCOVID11,SCOVID12,SCOVID13,SCOVID14,SCOVID15,SCOVID16,SCOVID17,SCOVID18,SCOVID19,SCOVID20)


# 开始流程
scRNA=sce.all
##计算质控指标
#计算细胞中核糖体基因比例
scRNA[["percent.mt"]] <- PercentageFeatureSet(scRNA, pattern = "^MT-")
#计算红细胞比例
HB.genes <- c("HBA1","HBA2","HBB","HBD","HBE1","HBG1","HBG2","HBM","HBQ1","HBZ")
HB_m <- match(HB.genes, rownames(scRNA@assays$RNA)) 
HB.genes <- rownames(scRNA@assays$RNA)[HB_m] 
HB.genes <- HB.genes[!is.na(HB.genes)] 
scRNA[["percent.HB"]]<-PercentageFeatureSet(scRNA, features=HB.genes) 
col.num <- length(levels(scRNA@active.ident))
#质控前
violin <- VlnPlot(scRNA,
                  features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.HB"), 
                  cols =rainbow(col.num), 
                  pt.size = 0.01, #不需要显示点，可以设置pt.size = 0
                  ncol = 4) + 
  theme(axis.title.x=element_blank(), axis.text.x=element_blank(), axis.ticks.x=element_blank()) 

violin

##设置质控标准，按照你给我的文献来定，如果发现后面结果不太满意，可以调整一下阈值，但是影响不大的
print(c("请输入允许基因数和核糖体比例，示例如下：", "minGene=200", "maxGene=2500", "pctMT=10",'pctHB=3'))
minGene=200
maxGene=2500
pctMT=20
pctHB=5

##1.数据质控----
scRNA <- subset(scRNA, subset = nFeature_RNA > minGene & nFeature_RNA < maxGene & percent.mt < pctMT & percent.HB < pctHB)

col.num <- length(levels(scRNA@active.ident))
violin <-VlnPlot(scRNA,
                 features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.HB"), 
                 cols =rainbow(col.num), 
                 pt.size = 0.1, 
                 ncol = 4) + 
  theme(axis.title.x=element_blank(), axis.text.x=element_blank(), axis.ticks.x=element_blank()) 
violin
# 标准化
scRNA <- NormalizeData(scRNA, normalization.method = "LogNormalize", scale.factor = 10000)
#DimPlot(scRNA,reduction = "pca",group.by = "orig.ident")
#2.降维和聚类#########################
library(Seurat)
library(tidyverse)
library(patchwork)

#高变基因3000个
scRNA <- FindVariableFeatures(scRNA, selection.method = "vst", nfeatures = 2000) #2000或者3000都是可以的

scale.genes <-  VariableFeatures(scRNA)
scRNA <- ScaleData(scRNA, features = scale.genes)

scRNA <- RunPCA(scRNA, features = VariableFeatures(scRNA)) 









plot1 <- DimPlot(scRNA, reduction = "pca", group.by="orig.ident") 
plot2 <- ElbowPlot(scRNA, ndims=20, reduction="pca") 
plotc <- plot1+plot2
plotc

# 选取平缓的elbow，不用更改
pc.num=1:10

scRNA <- FindNeighbors(scRNA, dims = pc.num) 
# 聚类
scRNA <- FindClusters(scRNA)
#UMAP可视化
scRNA <- RunUMAP(scRNA, dims = pc.num)
embed_umap <- Embeddings(scRNA, 'umap')
plot2 = DimPlot(scRNA, reduction = "umap",label = T) 
plot2
plot3 <- DimPlot(scRNA,group.by = "orig.ident",label = T)
plot3










# 自动注释 --------------------------------------------------------------------

###3.细胞类型鉴定（SingleR）
### 安装SingleR   BiocManager::install('SingleR')
#3.1自动注释\
library(SingleR)
#refdata <- SingleR::MouseRNAseqData()
#refdata <- HumanPrimaryCellAtlasData()#可选
#save(refdata,file ='refdata_singleR.Rdata')
load('./refdata_singleR.Rdata')
testdata <- GetAssayData(scRNA, slot="data")
clusters <- scRNA@meta.data$seurat_clusters
cellpred <- SingleR(test = testdata, ref = refdata,
                    labels =refdata$label.main,
                    method = "cluster", clusters = clusters, 
                    assay.type.test = "logcounts", assay.type.ref = "logcounts")

celltype = data.frame(ClusterID=rownames(cellpred), celltype=cellpred$labels, stringsAsFactors = F)

scRNA@meta.data$celltype = "NA"
for(i in 1:nrow(celltype)){
  scRNA@meta.data[which(scRNA@meta.data$seurat_clusters == celltype$ClusterID[i]),'celltype'] <- celltype$celltype[i]}
DimPlot(scRNA)
p2 = DimPlot(scRNA, group.by="celltype", label=T, label.size=3.5, reduction='umap',
             split.by = "orig.ident"
)
p2#p2这步骤split.by可以对注释的细胞进行分页面，比如分为IPF组和正常组

table(scRNA@meta.data$celltype)



#### ！！！！！----
Idents(scRNA)=scRNA$celltype 
DimPlot(scRNA,label = T)




celltype <- celltype$celltype





Idents(scRNA) <- scRNA@meta.data$seurat_clusters
names(celltype) <- levels(scRNA)
scRNA<- RenameIdents(scRNA, celltype)

scRNA@meta.data$celltype <- Idents(scRNA)
#!!!!!!改颜色
Idents(scRNA)=scRNA@meta.data$celltype

colors=c("#FF34B3","#BC8F8F","#20B2AA","#00F5FF","#FFA500","#ADFF2F",
         "#FF6A6A","#7FFFD4", "#AB82FF","#90EE90","#00CD00","#008B8B",
         "#6495ED","#FFC1C1","#CD5C5C","#8B008B","#FF3030", "#7CFC00")
p1 = DimPlot(scRNA, group.by="celltype", label=T, label.size=5, reduction='tsne',pt.size = 1,cols = colors)
p1
p2 = DimPlot(scRNA, group.by="celltype", label=T, label.size=5, reduction='umap',pt.size = 1,cols = colors)
p2
p3 = plotc <- p1+p2+ plot_layout(guides = 'collect')
p3
FeaturePlot(scRNA,features = 'VNN1',split.by="orig.ident",label=T)















FeaturePlot(scRNA,features = 'CCL2',split.by = 'orig.ident',label=T)
FeaturePlot(scRNA,features = 'TPST1',split.by = 'orig.ident',label=T)
FeaturePlot(scRNA,features = 'CCL7',split.by = 'orig.ident',label=T)
FeaturePlot(scRNA,features = 'CHST15',split.by = 'orig.ident',label=T)

saveRDS(scRNA,file ='scRNA_anno_self.rds')




# 手动注释 ----------------------------------------------------------------------


###鉴定细胞类型

habermann_imm <- c('CD274',"CD3E", "CD4", "FOXP3", "IL7R", "IL2RA", "CD40LG", "CD8A", "CCL5", "NCR1", "KLRB1", "NKG7", "LYZ", "CD68", "ITGAX", "MARCO", "FCGR1A", "FCGR3A", "C1QA", "APOC1", "S100A12", "FCN1", "S100A9", "CD14", "FCER1A", "CD1C", "CD16", "CLEC9A", "LILRA4", "CLEC4C", "JCHAIN", "IGHG1", "IGLL5", "MS4A1", "CD19", "CD79A", "CPA3",'GATA3', "KIT", "MKI67", "CDK1", "EPCAM")
#   
habermann_stromal <- c("VWF", "PECAM1", "ACTA2", "CCL21", "PROX1" , "MYH11", "PDGFRB", "WT1", "UPK3B", "LUM", "PDGFRA", "MYLK")
#注释：VWF,PECAM是内皮；"CCL21", "PROX1"是淋巴内皮细胞；"PDGFRB""LUM"是成纤维细胞；ACTA2,PDGFRA,LUM,MYLK,PDGFRB是肌纤维细胞；ACTA2，MYLK,PDGFRB,MYH11是平滑肌细胞，"WT1", "UPK3B"是间皮细胞，

habermann_epi <- c("EPCAM","CDH1","KRT7","KRT19","AGER","PDPN","ABCA3","SFTPB","SFTPC","SCGB1A1","MUC5B","KRT5","KRT17","NGFR","TRP63","FOXJ1","TMEM190","CAPS","ASCL1","CALCA","CHGA")





DotPlot(scRNA, features = habermann_imm,group.by = "seurat_clusters") + coord_flip()
DotPlot(scRNA, features = habermann_stromal,group.by = "seurat_clusters") + coord_flip()
DotPlot(scRNA, features = habermann_epi,group.by = "seurat_clusters") + coord_flip()

DotPlot(scRNA,group.by ="patient" )

scRNA_p$patient=scRNA$patient

## 结果可视化，群太多自行加颜色



celltype <- c('Endothelial_cells','Monocytes_cells','Monocytes_cells','Monocytes_cells',
              'Smooth muscle_cells','Macrophages_cells','T_cells','Endothelial_cells',
              'Fibroblasts_cells','Epithelial_cells','NK_cells','Macrophages_cells',
              'Macrophages_cells','Endothelial_cells',"Fibroblasts_cells","Plasma cells",
              "B_cells","Monocytes_cells","Epithelial_cells","Smooth muscle_cells",
              "Monocytes_cells","Epithelial_cells","Epithelial_cells","Mast_cells",
              "Endothelial_cells","Monocytes_cells")

Idents(scRNA) <- scRNA@meta.data$seurat_clusters
names(celltype) <- levels(scRNA)
scRNA<- RenameIdents(scRNA, celltype)

scRNA@meta.data$celltype <- Idents(scRNA)
#!!!!!!
Idents(scRNA)=scRNA@meta.data$celltype

colors=c('#313c63','#b42e20','#ebc03e','#377b4c',
         '#7bc7cd','#5d84a4','#bc3c29',"#FF34B3","#BC8F8F","#20B2AA","#00F5FF","#FFA500","#ADFF2F",
         "#FF6A6A","#7FFFD4", "#AB82FF","#90EE90","#00CD00","#008B8B",
         "#6495ED","#FFC1C1","#CD5C5C","#8B008B","#FF3030","#7CFC00")#),http://127.0.0.1:47539/graphics/plot_zoom_png?width=1069&height=900

p1 = DimPlot(scRNA, group.by="celltype", label=T, label.size=5, reduction='tsne',pt.size = 1,cols = colors)
p1
p2 = DimPlot(scRNA, group.by="celltype", label=T, label.size=5, reduction='umap',pt.size = 1)
p2
p3 = plotc <- p1+p2+ plot_layout(guides = 'collect')
p3
p4 <- DimPlot(scRNA,group.by = "celltype",label = T,label.size = 5,reduction = "umap",pt.size = 1,split.by = "orig.ident")
FeaturePlot(scRNA,features = 'EFCAB1',split.by = 'orig.ident',label=T)

saveRDS(scRNA,file = "scRNA.IPF+Normal.RDS")
rm(list = ls())
scRNA <- readRDS(file = "scRNA.IPF+Normal.RDS")




#亚群注释基因热图展现----

markerdf1 <- read.table(file = "读取大亚群的marker1.txt",sep = "\t",check.names = F,header = T)
markerdf1$gene=as.character(markerdf1$gene)

DoHeatmap(scRNA,features = markerdf1$gene,label = F,slot = "scale.data")










#亚群注释基因气泡图展现----
marker <- c("PTPRC","CD3D","CD3E","CD3G","CD79","MS4A1","SDC1","ITGAM","CD68","CD11c","CD14","KLRB1","KLRD1")
DotPlot(scRNA, features = marker)+coord_flip()+
  theme_bw()+
  theme(panel.grid = element_blank(), axis.text.x=element_text(hjust = 1,vjust=0.5))+
  labs(x=NULL,y=NULL)+guides(size=guide_legend(order=3))+
  scale_color_gradientn(values = seq(0,1,0.2),colours = c('#330066','#336699','#66CC66','#FFCC33'))


#单个基因在不同亚群的表达量----

VlnPlot(scRNA, features = "VNN1")
VlnPlot(subset(scRNA,VNN1>0.2), features = "VNN1")








#分群比例柱状图----
table(scRNA@meta.data$orig.ident)
prop.table(table(scRNA@meta.data$orig.ident))
table(scRNA@meta.data$celltype)
prop.table(table(scRNA@meta.data$celltype))
table(scRNA@meta.data$celltype,scRNA$orig.ident)
Cellratio <- prop.table(table(Idents(scRNA),scRNA$patient),margin=2)

Cellratio <- as.data.frame(Cellratio)
colnames(Cellratio)[1] <- "celltype"
colourCount = length(unique(Cellratio$celltype))
library(ggplot2)
ggplot(Cellratio) + 
  geom_bar(aes(x =Var2, y= Freq, fill = celltype),stat = "identity",width = 0.3,size = 0.1)+ 
  scale_fill_manual(values = c('#313c63','#008B8B','#5d84a4','#7bc7cd','#ebc03e'
                               ,'#d98f34',"#800000","#b42e20","#BC8F8F","#008000","#c4ffc5")) +
  theme_classic() +
  labs(x='Sample',y = 'Ratio')+
  coord_flip()+
  theme(panel.border = element_rect(fill=NA,color="black", size=0.5, linetype="solid"))
#点图----
table(scRNA$orig.ident)#查看各组细胞数
prop.table(table(Idents(scRNA)))
table(Idents(scRNA), scRNA$orig.ident)#各组不同细胞群细胞数
Cellratio <- prop.table(table(Idents(scRNA), scRNA$patient), margin = 2)#计算各组样本不同细胞群比例
Cellratio <- data.frame(Cellratio)
library(reshape2)
cellper <- dcast(Cellratio,Var2~Var1, value.var = "Freq")#长数据转为宽数据
rownames(cellper) <- cellper[,1]
cellper <- cellper[,-1]
###添加分组信息
sample <- c("IPF_all1","IPF_all2","IPF_all3","Normal_all1","Normal_all2","Normal_all3")
group <- c("IPF_all","IPF_all","IPF_all","Normal_all","Normal_all","Normal_all")
samples <- data.frame(sample, group)#创建数据框
rownames(samples)=samples$sample
cellper$sample <- samples[rownames(cellper),'sample']#R添加列
cellper$group <- samples[rownames(cellper),'group']#R添加列


###作图展示 
pplist = list()
sce_groups = c('Endothelial_cells','Monocytes_cells','Smooth muscle_cells',
               'Macrophages_cells','T_cells',"Fibroblasts_cells",
               "Epithelial_cells","NK_cells","Plasma cells","B_cells","Mast_cells")
library(ggplot2)
library(dplyr)
library(ggpubr)
library(cowplot)
for(group_ in sce_groups){
  cellper_  = cellper %>% select(one_of(c('sample','group',group_)))#选择一组数据
  colnames(cellper_) = c('sample','group','percent')#对选择数据列命名
  cellper_$percent = as.numeric(cellper_$percent)#数值型数据
  cellper_ <- cellper_ %>% group_by(group) %>% mutate(upper =  quantile(percent, 0.75), 
                                                      lower = quantile(percent, 0.25),
                                                      mean = mean(percent),
                                                      median = median(percent))#上下分位数
  print(group_)
  print(cellper_$median)


pp1 = ggplot(cellper_,aes(x=group,y=percent)) + #ggplot作图
  geom_jitter(shape = 21,aes(fill=group),width = 0.25) + 
  stat_summary(fun=mean, geom="point", color="grey60") +
  theme_cowplot() +
  theme(axis.text = element_text(size = 10),axis.title = element_text(size = 10),legend.text = element_text(size = 10),
        legend.title = element_text(size = 10),plot.title = element_text(size = 10,face = 'plain'),legend.position = 'none') + 
  labs(title = group_,y='Percentage') +
  geom_errorbar(aes(ymin = lower, ymax = upper),col = "grey60",width =  1)


labely = max(cellper_$percent)
compare_means(percent ~ group,  data = cellper_)
my_comparisons <- list( c("IPF_all", "Normal_all") )
pp1 = pp1 + stat_compare_means(comparisons = my_comparisons,size = 3,method = "t.test")
pplist[[group_]] = pp1
}

library(cowplot)
plot_grid(pplist[['Epithelial_cells']],
          pplist[['Endothelial_cells']],
          pplist[['Monocytes_cells']],
          pplist[['Smooth muscle_cells']],
          pplist[['Macrophages_cells']],
          pplist[['T_cells']],
          pplist[['Fibroblasts_cells']],
          pplist[['Plasma cells']],
          pplist[['NK_cells']],
          pplist[['B_cells']]
          )









#中性粒----
library(DESeq2)
library(tidyverse)
Ne.cell <-  subset(scRNA,celltype=="Neutrophils")



Idents(Ne.cell) <- Ne.cell@meta.data$orig.ident
deg <- FindMarkers(Ne.cell,ident.1="Contral",
                                   ident.2="SCOVID",
                                   assay = "RNA",
                                   test.use = "wilcox",
                      logfc.threshold = 0.1,min.pct = 0.1)

VlnPlot(Ne.cell, features = "VNN1",ncol = 5, group.by = "orig.ident", 
        assay = "RNA", pt.size = 0.1)







#巨噬细胞（峰）----
library(DESeq2)
library(tidyverse)

Macro.cells <- subset(scRNA,celltype=="Macrophage_cells")
Idents(Macro.cells)

Idents(Macro.cells) <- Macro.cells@meta.data$orig.ident
Macro.cells.diff <- FindAllMarkers(Macro.cells,
                                   ident.1="Normal_all",
                                   ident.2="IPF_all",
                                   assay = "RNA",
                                   test.use = "wilcox")
dput(rownames(head(Macro.cells.diff)))
Macro.up.diff <- filter(Macro.cells.diff,avg_log2FC>0.25)
Macro.down.diff<- filter(Macro.cells.diff,avg_log2FC<(-0.25))
Macro.diff <- rbind(Macro.up.diff,NMacro.down.diff)



#B
B.cells <- subset(scRNA,celltype=="B_cell")
Idents(B.cells)
Idents(B.cells) <- B.cells@meta.data$orig.ident
B.cells.diff <- FindMarkers(B.cells,
                            ident.1="Normal_all",
                            ident.2="IPF_all",
                            assay = "RNA",
                            test.use = "DESeq2")
dput(rownames(head(B.cells.diff)))


#NK
NK.cells <- subset(scRNA,celltype=="NK_cell")
Idents(NK.cells)
Idents(NK.cells) <- NK.cells@meta.data$orig.ident
NK.cells.diff <- FindMarkers(NK.cells,
                            ident.1="Normal_all",
                            ident.2="IPF_all",
                            assay = "RNA",
                            test.use = "DESeq2",logfc.threshold = 0.25)
dput(rownames(head(NK.cells.diff)))
NK.up.diff <- filter(NK.cells.diff,avg_log2FC>0.25)
NK.down.diff<- filter(NK.cells.diff,avg_log2FC<(-0.25))
NK.diff <- rbind(NK.up.diff,NK.down.diff)
write.table(NK.diff,file = "NK.diff.txt",sep = "\t")



#T
T.cells <- subset(scRNA,celltype=="T_cells")
Idents(T.cells)
Idents(T.cells) <- T.cells@meta.data$orig.ident
T.cells.diff <- FindMarkers(T.cells,
                             ident.1="Normal_all",
                             ident.2="IPF_all",
                             assay = "RNA",
                             test.use = "DESeq2")
dput(rownames(head(T.cells.diff)))
T.up.diff <- filter(T.cells.diff,avg_log2FC>0.25)
T.down.diff<- filter(T.cells.diff,avg_log2FC<(-0.25))
T.diff <- rbind(T.up.diff,T.down.diff)
write.table(T.diff,file = "T.diff.txt",sep = "\t")

#平滑肌
smooth.cells <- subset(scRNA,celltype=="Smooth_muscle_cells")
Idents(smooth.cells)
Idents(smooth.cells) <- smooth.cells@meta.data$orig.ident
smooth.cells.cells.diff <- FindMarkers(smooth.cells,
                            ident.1="Normal_all",
                            ident.2="IPF_all",
                            assay = "RNA",
                            test.use = "DESeq2")
dput(rownames(head(smooth.cells.cells.diff)))
smooth.cells.up.diff <- filter(smooth.cells.cells.diff,avg_log2FC>0.25)
smooth.cells.down.diff<- filter(smooth.cells.cells.diff,avg_log2FC<(-0.25))
smooth.cells.diff <- rbind(smooth.cells.up.diff,T.down.diff)
write.table(T.diff,file = "smooth.cells.diff.txt",sep = "\t")

#上皮----
Epi.cells <- subset(scRNA,celltype=="Epithelial_cells")
#Epi.cells@assays$RNA@data <- Epi.cells@assays$RNA@data[rowSums(Epi.cells@assays$RNA@data>0),]
# df <- Epi.cells@assays$RNA@data
# df=as.data.frame(df)
# 
# df <- df[rowMeans(df) !=0,  ]
# df <- df[,colMeans(df) !=0 ]
# 
# ## 一点没表达的细胞去除
# Epi.cells=subset(Epi.cells,id %in% colnames(df))



Idents(Epi.cells)
Idents(Epi.cells) <- Epi.cells@meta.data$orig.ident
Epi.cells.diff <- FindMarkers(Epi.cells,
                                       ident.1="Normal_all",
                                       ident.2="IPF_all",
                                       assay = "RNA",
                                       test.use = "wilcox")
dput(rownames(head(Epi.cells)))
Epi.cells.up.diff <- filter(Epi.cells.diff,avg_log2FC>1)
Epi.cells.down.diff<- filter(Epi.cells.diff,avg_log2FC<(-1))

Epi.cells.diff <- rbind(Epi.cells.up.diff,Epi.cells.down.diff)
write.table(Epi.cells.diff,file = "Epi.cells.diff.txt",sep = "\t")

Epi.cells.diff <- read.table(file = "Epi.cells.diff.txt",sep = "\t")

#差异基因火山图----
foldChange <- 1
padj <- 0.05
pdf('volcano.pdf',width = 7,height = 6.5)  ## 输出文件
Epi.cells.diff$label <- ifelse(Epi.cells.diff$p_val_adj< padj & abs(Epi.cells.diff$avg_log2FC) >=2.5,
                        as.character(rownames(Epi.cells.diff)), "")######！设置标签基因范围


ggplot(Epi.cells.diff, aes(avg_log2FC, -log10(p_val_adj)))+#建立横纵坐标
  geom_point(aes(col=group))+#建造点图
  scale_color_manual(values=c("#0072B5","grey","#BC3C28"))+#改变点颜色
  labs(title = "COVID19")+#加标题备注
  geom_vline(xintercept=c(-1,1), colour="black", linetype="dashed")+#加线
  geom_hline(yintercept = -log10(0.05),colour="black", linetype="dashed")+
  theme(plot.title = element_text(size = 16, hjust = 0.5, face = "bold"))+
  labs(x="log2(FoldChange)",y="-log10(Pvalue)")+
  theme(axis.text=element_text(size=13),axis.title=element_text(size=13))+
  str(diffsig, max.level = c(-1, 1))+theme_bw()+
  geom_label_repel(data = diffsig, aes(x = diffsig$logFC, 
                                       y = -log10(diffsig$adj.P.Val), 
                                       label = label),
                   size = 3, box.padding = unit(0.5, "lines"),
                   point.padding = unit(0.8, "lines"), 
                   segment.color = "black", 
                   show.legend = FALSE)
dev.off()















#基因气泡图----
IPFsnRNA <-subset(scRNA,orig.ident=="IPF_all") 
immuse_cox <- read.table(file = "immuse_cox.txt")
x1 <- immuse_cox$V1[1:20]
x2 <- immuse_cox$V1[21:40]
x3 <- immuse_cox$V1[41:60]
x4 <- immuse_cox$V1[61:80]
x5 <- immuse_cox$V1[81:100]
x6 <- immuse_cox$V1[101:120]
x7 <- immuse_cox$V1[121:140]
x8 <- immuse_cox$V1[141:160]
x9 <- immuse_cox$V1[161:180]
x10 <- immuse_cox$V1[201:220]
x11 <- immuse_cox$V1[221:240]
x12 <- immuse_cox$V1[241:260]
x13 <- immuse_cox$V1[261:280]
x14 <- immuse_cox$V1[281:300]
x15 <- immuse_cox$V1[301:320]
x16 <- immuse_cox$V1[321:342]



DotPlot(IPFsnRNA,features =x1 )

EPI <- subset(scRNA,celltype=="Epithelial_cells")
df <- FindMarkers(EPI,)












#NMF----

immuse_cox <- read.table(file = "immuse_cox.txt")
Epi.cells.diff <- read.table(file = "Epi.cells.diff.txt",sep = "\t",check.names = F)
gene <- intersect(immuse_cox$V1,rownames(Epi.cells.diff))
#gene <- read.table(file = "30.txt")
#gene <- gene$V1
library(NMF)
Epi.cells <- subset(scRNA,celltype=="Epithelial_cells")
Epi.cells <- subset(Epi.cells,orig.ident=="IPF_all")
# 查看细胞数目
dim(Epi.cells)
Epi.cells$id=colnames(Epi.cells)
Epi.cells_aa=Epi.cells[rownames(Epi.cells) %in% gene,]
df <- Epi.cells_aa@assays$RNA@data
df=as.data.frame(df)

df <- df[rowMeans(df) !=0,  ]
df <- df[,colMeans(df) !=0 ]
Epi.cells=subset(Epi.cells,id %in% colnames(df))


# 开始nmf
#install.packages("NMF")  
library(NMF)
res <- nmf(df, 10, method = "snmf/r", seed = 'nndsvd')
## NMF结果返回suerat对象
Epi.cells@reductions$nmf <- Epi.cells@reductions$pca
Epi.cells@reductions$nmf@cell.embeddings <- t(coef(res))    
Epi.cells@reductions$nmf@feature.loadings <- basis(res)  
set.seed(999)
library(Seurat)
Epi.cells.nmf <- RunUMAP(Epi.cells, reduction = 'nmf', dims = 1:10) 
Epi.cells.nmf <- FindNeighbors(Epi.cells.nmf,reduction = 'nmf', dims = 1:10)
Epi.cells.nmf <- FindClusters(Epi.cells.nmf)

Epi.cells.nmf$NMF_cluster=Epi.cells.nmf$seurat_clusters
Idents(Epi.cells.nmf) <- Epi.cells.nmf@meta.data$NMF_cluster
## 结果可视化，群太多自行加颜色
DimPlot(Epi.cells.nmf, label = T) 
#DimPlot(Epi.cells.nmf, label = T,split.by = "orig.ident") 


df=FindAllMarkers(Epi.cells.nmf,logfc.threshold = 0.5,only.pos = T)
df1 <- filter(df,avg_log2FC>1)
# write.table(df1,file = "epi_NMFcluster_logFC1_DEG.txt",sep = "\t")
 c0 <- filter(df1,cluster==0)
 c0m <- intersect(rownames(c0),gene)
# c1 <- filter(df1,cluster==1)
# c1m <- intersect(rownames(c1),gene)
# c2 <- filter(df1,cluster==2)
# c2m <- intersect(rownames(c2),gene)
# c3 <- filter(df1,cluster==3)
# c3m <- intersect(rownames(c3),gene)
# c4 <- filter(df1,cluster==4)
# c4m <- intersect(rownames(c4),gene)
# c5 <- filter(df1,cluster==5)
# c5m <- intersect(rownames(c5),gene)
# c6 <- filter(df1,cluster==6)
# c6m <- intersect(rownames(c6),gene)
# c7 <- filter(df1,cluster==7)
# c7m <- intersect(rownames(c7),gene)
# d <- which(rownames(df)%in%gene,)
# df2 <- df[d1,]
# df3 <- rbind(c0,c1,c2,c3,c4,c5,c6,c7)

## 画图看一看
FeaturePlot(Epi.cells.nmf,features = Ciliated.cells)
FeaturePlot(Epi.cells.nmf,features = Basal.cells)
FeaturePlot(Epi.cells.nmf,features = Suprabasal.cells)


DotPlot(Epi.cells.nmf, features = Basal.cells,group.by = "NMF_cluster") + coord_flip()
DotPlot(Epi.cells.nmf, features = Suprabasal.cells,group.by = "NMF_cluster") + coord_flip()
DotPlot(Epi.cells.nmf, features = Secretory.cells,group.by = "NMF_cluster") + coord_flip()
DotPlot(Epi.cells.nmf, features = Deuterosomal.cells,group.by = "NMF_cluster") + coord_flip()
DotPlot(Epi.cells.nmf, features = Ciliated.cells,group.by = "NMF_cluster") + coord_flip()
DotPlot(Epi.cells.nmf, features = Mucous_ciliated.cells,group.by = "NMF_cluster") + coord_flip()

DotPlot(Epi.cells.nmf, features = Ionocyte,group.by = "NMF_cluster") + coord_flip()
DotPlot(Epi.cells.nmf, features = Pulmonary,group.by = "NMF_cluster") + coord_flip()
DotPlot(Epi.cells.nmf, features = Tuft,group.by = "NMF_cluster") + coord_flip()
DotPlot(Epi.cells.nmf, features = Hillock,group.by = "NMF_cluster") + coord_flip()

DotPlot(Epi.cells.nmf, features = AT1,group.by = "NMF_cluster") + coord_flip()
DotPlot(Epi.cells.nmf, features = AT2,group.by = "NMF_cluster") + coord_flip()








x1 <- df1[c0m,]



## 拟时序分析----
library(Seurat)
#没有monocle要先安装 BiocManager::install()
#BiocManager::install('monocle',update = F,ask = F)

#没有的包先安装
library(BiocGenerics)
library(monocle)
library(tidyverse)
library(patchwork)
data=as.matrix(Epi.cells.nmf@assays$RNA@counts)

data <- as(data, 'sparseMatrix')
pd <- new('AnnotatedDataFrame', data = Epi.cells.nmf@meta.data)
fData <- data.frame(gene_short_name = row.names(data), row.names = row.names(data))
fd <- new('AnnotatedDataFrame', data = fData)
## 以下代码一律不得修改
mycds <- newCellDataSet(data,
                        phenoData = pd,
                        featureData = fd,
                        expressionFamily = negbinomial.size())

mycds <- estimateSizeFactors(mycds)
mycds <- estimateDispersions(mycds, cores=4, relative_expr = TRUE)

##使用monocle选择的高变基因，不修改
disp_table <- dispersionTable(mycds)
disp.genes <- subset(disp_table, mean_expression >= 0.1 & dispersion_empirical >= 1 * dispersion_fit)$gene_id
mycds <- setOrderingFilter(mycds, disp.genes)
plot_ordering_genes(mycds)



#降维
mycds <- reduceDimension(mycds, max_components = 2, method = 'DDRTree')
#排序，报错请用4.1以上的R，并重装monocle
mycds <- orderCells(mycds)

ss=intersect(gene,rownames(Epi.cells.nmf))
dev.off()
my_pseudotime_cluster <- plot_pseudotime_heatmap(mycds[ss,],
                                                 # num_clusters = 2, # add_annotation_col = ac,
                                                 show_rownames = TRUE,
                                                 return_heatmap = TRUE)

my_pseudotime_cluster 


#State轨迹分布图
plot1 <- plot_cell_trajectory(mycds, color_by = "State")
plot1

plot4 <- plot_cell_trajectory(mycds, color_by = "NMF_cluster")
plot4

##合并出图
plotc <- plot1|plot4
plotc


#定义新的细胞亚群----
#NMF_celltype <- c("SNTN+FAM183A+Ciliated-C0","STFBA1+SFBA2+AT2-C1","KRT17+KRT15+Basal-C2","BBOF2+TMEM190+Ciliated-C3","MUC5B+BPIFB1+club-C4","SCGB1A1+SCGB1A2+club-C5","TMSB4X+SFTA2+epi-C6")
#NMF_celltype <- c("Ciliated-C0","AT2-C1","Basal-C2","Ciliated-C3","Club-C4","Club-C5","Epi-C6"))NMF_celltype <- c("-C0","AT2-C1","Club-C2","Basal-C3","Club-C4","Ciliated-C5")
NMF_celltype <- c("TPPP3+C0","SFPTC+C1","KRT17+C2","TMEM190+C3","MAMB+C4","SCGB1A1+C5","AGER+C6")
Idents(Epi.cells.nmf) <- Epi.cells.nmf@meta.data$NMF_cluster
names(NMF_celltype) <- levels(Epi.cells.nmf)
Epi.cells.nmf <- RenameIdents(Epi.cells.nmf,NMF_celltype)
Epi.cells.nmf@meta.data$NMF_celltype <- Idents(Epi.cells.nmf)
Idents(Epi.cells.nmf) <- Epi.cells.nmf@meta.data$NMF_celltype
DimPlot(Epi.cells.nmf,group.by = "NMF_celltype")
DimPlot(Epi.cells.nmf,group.by = "NMF_cluster")
#saveRDS(Epi.cells.nmf,file = "Epi.cells.nmf.RDS")
FeaturePlot(Epi.cells.nmf,features = "C12orf75")
FeaturePlot(Epi.cells.nmf,features = "TPPP3")










#细胞通讯----



scRNA <- readRDS(file = "scRNA.IPF+Normal.RDS")
IPFsnRNA <- subset(scRNA,orig.ident=="IPF_all")
#IPF_epi.nmf <- readRDS(file = "Epi.cells.nmf.RDS")

IPF_epi.nmf <- Epi.cells.nmf
# scRNA_chat <-subset(IPFsnRNA, celltype %in%c('Endothelial_cells',"Monocytes_cells Smooth","Monocytes_cells","Macrophages_cells","T_cells","Fibroblasts_cells","NK_cells","Plasma cells","B_cells","Mast_cells"))




#做1种通讯
scRNA_chat <-subset(IPFsnRNA, celltype=='T_cells')
scRNA_chat$NMF_celltype='T_cells'







scRNA_chat=merge(scRNA_chat,IPF_epi.nmf)
meta =scRNA_chat@meta.data # a dataframe with rownames containing cell mata data

data_input <- as.matrix(scRNA_chat@assays$RNA@data)
#data_input=data_input[,rownames(meta)]
identical(colnames(data_input),rownames(meta))

library(CellChat)
cellchat <- createCellChat(object = data_input, meta = meta, group.by = "NMF_celltype")

CellChatDB <- CellChatDB.human 
groupSize <- as.numeric(table(cellchat@idents))
CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling") 
cellchat@DB <- CellChatDB.use 

dplyr::glimpse(CellChatDB$interaction)##配体-受体分析
# 提取数据库支持的数据子集
cellchat <- subsetData(cellchat)
# 识别过表达基因
cellchat <- identifyOverExpressedGenes(cellchat)
# 识别配体-受体对
cellchat <- identifyOverExpressedInteractions(cellchat)
# 将配体、受体投射到PPI网络
cellchat <- projectData(cellchat, PPI.human)
unique(cellchat@idents)

cellchat <- computeCommunProb(cellchat)

# Filter out the cell-cell communication if there are only few number of cells in certain cell groups
cellchat <- filterCommunication(cellchat, min.cells = 10)
cellchat <- computeCommunProbPathway(cellchat)

df.net<- subsetCommunication(cellchat)

cellchat <- aggregateNet(cellchat)
groupSize <- as.numeric(table(cellchat@idents))

##时常deff.off!!!!
dev.off()
netVisual_circle(cellchat@net$count, vertex.weight = groupSize, 
                 weight.scale = T, label.edge= T, sources.use = 'Macrophages_cells',
                 title.name = "Number of interactions")
#sources.use需要改为需要研究的细胞,表示从研究的细胞发出的通讯，（去掉后即为双向？）
dev.off()

netVisual_circle(cellchat@net$weight, vertex.weight = groupSize, 
                 weight.scale = T, label.edge= T, 
                 title.name = "Interaction weights/strength")


cellchat <- netAnalysis_computeCentrality(cellchat, slot.name = "netP")
netAnalysis_signalingRole_network(cellchat, signaling = 'GAS', width = 8, height = 2.5, font.size = 10)


h1=netAnalysis_signalingRole_heatmap(cellchat, pattern = "outgoing")
h2=netAnalysis_signalingRole_heatmap(cellchat, pattern = "incoming")
h1 + h2


###提取不同亚群的标记基因----









#转录因子----
scRNAsub=readRDS('Epi.cells.nmf.RDS')

library(SCENIC)
library(Seurat)
exprMat <- as.matrix(scRNAsub@assays$RNA@counts)
cellInfo <-scRNAsub@meta.data
# 进入子文件夹
setwd("SCENIC") 

Idents(scRNAsub)=scRNAsub$NMF_celltype
### Initialize settings
dir.create("int")
saveRDS(cellInfo, file="int/cellInfo.Rds")

Idents(scRNAsub) <- "NMF_cluster"
# 人物种
org='hgnc'


dbDir="./SCENIC" # RcisTarget databases location
myDatasetTitle="SCENIC Challenge" # choose a name for your analysis
data(defaultDbNames)
dbs <- defaultDbNames[[org]]
dbs

data(list="motifAnnotations_hgnc_v9", package="RcisTarget")
motifAnnotations_hgnc <- motifAnnotations_hgnc_v9



scenicOptions <- initializeScenic(org=org,
                                  dbDir=dbDir, 
                                  dbs = dbs,
                                  nCores=10)

scenicOptions@inputDatasetInfo$cellInfo <- "cellInfo.Rds"
scenicOptions@inputDatasetInfo$colVars <- "colVars.Rds"
# 节省内存，我们只取一个基因组文件
# 人：用下面！！！！！！！！！


scenicOptions@settings$dbs <- c("mm9-5kb-mc8nr" = "hg19-tss-centered-10kb-7species.mc9nr.feather")
scenicOptions@settings$db_mcVersion <- "v9"
saveRDS(scenicOptions, file="scenicOptions.Rds") 
#Gene filter: Filter by the number of cells in which the gene is detected (minCountsPerGene, by default 6 UMI counts across all samples)
# and by the number of cells in which the gene is detected (minSamples, by default 1% of the cells)
# 尽可能减少基因数目
# 如果需要更多基因，0.1调成0.05或0.01
genesKept <- geneFiltering(exprMat, scenicOptions=scenicOptions,minCountsPerGene=3*.1*ncol(exprMat),minSamples=ncol(exprMat)*.1)
exprMat_filtered <- exprMat[genesKept,]
dim(exprMat_filtered)
#calculating correlation
runCorrelation(exprMat_filtered, scenicOptions)

#GENIE3: infer potential transcription factor targets based on the expression data
exprMat_filtered <- log2(exprMat_filtered+1) 

# 等待较久的一步，纳入基因和细胞越多，等待越久，此处只用了1000多基因，200个细胞
# 对应的TF也只有100多个了，其实有1000多个TF，如果是性能好的计算机可以考虑前面0.1调成0.05或0.01
runGenie3(exprMat_filtered, scenicOptions)


scenicOptions@settings$verbose <- TRUE
scenicOptions@settings$nCores <- 1
scenicOptions@settings$seed <- 123

exprMat_log <- log2(exprMat+1)
dim(exprMat)
#scenicOptions@settings$dbs <- scenicOptions@settings$dbs["10kb"] # For toy run
scenicOptions <- runSCENIC_1_coexNetwork2modules(scenicOptions)

# step2容易崩，节省内存只看top50
gc()
scenicOptions <- runSCENIC_2_createRegulons(scenicOptions, coexMethod=c("top50")) #** Only for toy run!!

gc()
# 回到单线程！否则容易报错！！！！！
scenicOptions@settings$nCores <- 1
library(foreach)

scenicOptions <- runSCENIC_3_scoreCells(scenicOptions, exprMat_log)
saveRDS(scenicOptions, file="scenicOptions.Rds") # To save status

#============================================

#下次可以直接读取他,我们已经越过最耗时间的步骤
# 如果经常报错，不要重新readRDS和load，应不间断运行

#scenicOptions <- readRDS("scenicOptions.Rds")
#load('scRNAsub.Rdata')
scenicOptions@settings$seed <- 123 # same seed for all of them

#Binarizing the network
runSCENIC_4_aucell_binarize(scenicOptions)

aucell_regulonAUC <- loadInt(scenicOptions, "aucell_regulonAUC")
aucell_regulonAUC
aucell_regulonAUC.t <- t(aucell_regulonAUC@assays@data$AUC)
colnames(aucell_regulonAUC.t) <- gsub(" ", "_", colnames(aucell_regulonAUC.t))
rownames(aucell_regulonAUC.t) <- gsub("[.]", "-", rownames(aucell_regulonAUC.t))

fibro.scenic <- scRNAsub
# 结果导入endo.scenic
fibro.scenic@meta.data <- cbind(fibro.scenic@meta.data, aucell_regulonAUC.t[rownames(fibro.scenic@meta.data),])
dev.off()
DimPlot(fibro.scenic, reduction = "umap")
# 找6个
FeaturePlot(fibro.scenic, reduction = "umap", features = colnames(fibro.scenic@meta.data)[20:27], cols = c("yellow", "red"))

#Regulon scores heatmap 热图
Idents(fibro.scenic)=fibro.scenic$NMF_celltype
cells.ord.cluster <- fibro.scenic@active.ident
cells.ord.cluster<- cells.ord.cluster[order(cells.ord.cluster)]
regulon.scores <- t(aucell_regulonAUC.t[names(cells.ord.cluster),])
regulon.scores.log <- log(regulon.scores +1)
regulon.scores.scaled <- scale(regulon.scores)

library(gplots)
library(pheatmap)

# 进一步标化
cal_z_score <- function(x){
  (x - mean(x)) / sd(x)
}
data_subset_norm <- t(apply(regulon.scores, 1, cal_z_score))
#pheatmap(data_subset_norm)

cluster.col <- data.frame(fibro.scenic@active.ident, row.names = names(fibro.scenic@active.ident))
colnames(cluster.col) <- "group"


#pheatmap::pheatmap(regulon.scores.scaled, cluster_rows = T,cluster_cols = F, annotation_col = cluster.col, show_colnames = F, fontsize_row=5)
#pheatmap::pheatmap(data_subset_norm, cluster_rows = T,cluster_cols = F, annotation_col = cluster.col, show_colnames = F)


#Average Regulon Activity 平均调控活性
regulonAUC <- loadInt(scenicOptions, "aucell_regulonAUC")
regulonAUC <- regulonAUC[onlyNonDuplicatedExtended(rownames(regulonAUC)),]
regulonActivity_byCellType <- sapply(split(rownames(cellInfo), cellInfo$NMF_celltype),
                                     function(cells) rowMeans(getAUC(regulonAUC)[,cells]))
regulonActivity_byCellType_Scaled <- t(scale(t(regulonActivity_byCellType), center = T, scale=T))
library(ggplot2)
library(cowplot)
pheatmap::pheatmap(regulonActivity_byCellType_Scaled,cluster_cols = F,cluster_rows = F,color = colorRampPalette(c(rep("blue",1), "white", rep("red",1)))(100))

dev.off()


##### 关键CAF基因的表达
# 回到外面的文件夹!!!!!!!!!!!!!!!!!！否则必然报错
setwd('..')
gc()






#C0-C3的转录因子----
scRNA <- readRDS(file = "scRNA.IPF+Normal.RDS")
immuse_cox <- read.table(file = "immuse_cox.txt")
Epi.cells.diff <- read.table(file = "Epi.cells.diff.txt",sep = "\t",check.names = F)
gene <- intersect(immuse_cox$V1,rownames(Epi.cells.diff))
library(NMF)
Epi.cells <- subset(scRNA,celltype=="Epithelial_cells")
Epi.cells <- subset(Epi.cells,orig.ident=="IPF_all")


#！！！！
E <- readRDS(file = "Epi.cells.nmf.RDS")
Epi.cells@meta.data$NMF <-E@meta.data$NMF_cluster 
Epi.cells<- subset(Epi.cells,NMF=="0"|NMF=="3")
# 查看细胞数目
dim(Epi.cells)
Epi.cells$id=colnames(Epi.cells)
Epi.cells_aa=Epi.cells[rownames(Epi.cells) %in% gene,]
df <- Epi.cells_aa@assays$RNA@data
df=as.data.frame(df)

df <- df[rowMeans(df) !=0,  ]
df <- df[,colMeans(df) !=0 ]
Epi.cells=subset(Epi.cells,id %in% colnames(df))
library(NMF)
res <- nmf(df, 10, method = "snmf/r", seed = 'nndsvd')
## NMF结果返回suerat对象
Epi.cells@reductions$nmf <- Epi.cells@reductions$pca
Epi.cells@reductions$nmf@cell.embeddings <- t(coef(res))    
Epi.cells@reductions$nmf@feature.loadings <- basis(res)  
set.seed(999)
library(Seurat)
Epi.cells.nmf <- RunUMAP(Epi.cells, reduction = 'nmf', dims = 1:10) 
Epi.cells.nmf <- FindNeighbors(Epi.cells.nmf,reduction = 'nmf', dims = 1:10)
Epi.cells.nmf <- FindClusters(Epi.cells.nmf)

Epi.cells.nmf$NMF_cluster=Epi.cells.nmf$seurat_clusters
Idents(Epi.cells.nmf) <- Epi.cells.nmf@meta.data$NMF_cluster
## 结果可视化，群太多自行加颜色
DimPlot(Epi.cells.nmf, label = T) 


#特定基因表达的图----
scRNA <- Epi.cells.nmf
fibro_avg=AverageExpression(scRNA,group.by = 'NMF_cluster')
fibro_avg=as.data.frame(fibro_avg)
colnames(fibro_avg)=c('C0','C1','C2',"C3","C4","C5","C6")
tme=read.table('Epimarker.txt')
tme=tme$V1
ss=intersect(tme,rownames(fibro_avg))
rt=fibro_avg[ss,]

pheatmap::pheatmap(rt,scale = 'row',cluster_cols = F,cluster_rows = F,
                   color = colorRampPalette(c(rep("#6495ED",1), "white", rep("#FF3030",1)))(100),legend = FALSE)





library(data.table)
library(readxl)


gene_set = read.table(file='Epicellmarker.txt', header = T, sep = '\t',stringsAsFactors = F)
list <- list()
for(i in 1:length(unique(gene_set$subcell))){
  list[[i]] <- gene_set$gene[gene_set$subcell== (unique(gene_set$subcell)[i])]
}
names(list)<- unique(gene_set$subcell)
library(Seurat)
names(list)
scRNA=AddModuleScore(scRNA,features = list)
colnames(scRNA@meta.data)
df=scRNA@meta.data[,c(11:16)]
a=aggregate(df[,2:6],list(df$NMF_cluster),mean)
a$Group.1 <- c("C0","C1","C2","C3","C4","C5","C6")
rownames(a)=a$Group.1

a$Group.1=NULL
colnames(a)=names(list)
a=t(a)
#a=a[,c(3,2,1)]
pheatmap::pheatmap(a,scale = 'row',cluster_cols = F,cluster_rows = F,
                   color = colorRampPalette(c(rep("#6495ED",1), "white", rep("#FF3030",1)))(100),
)



















#纤毛的亚群----


Ciliated.diff <-FindMarkers(Epi.cells.nmf,ident.1 = "TPPP3+C0",ident.2 = "TMEM190+C3") 
Ciliated.diff <- arrange(Ciliated.diff,avg_log2FC)
write.table(Ciliated.diff,file = "Ciliated.diff.txt",sep = "\t")
FeaturePlot(Epi.cells.nmf,features = "AGR2")
FeaturePlot(Epi.cells.nmf,features = "PIP")
FeaturePlot(Epi.cells.nmf,features = "SCGB3A2")
FeaturePlot(Epi.cells.nmf,features = "FABP6")


FeaturePlot(Epi.cells.nmf,features = "SAA1")
FeaturePlot(Epi.cells.nmf,features = "LCN2")
FeaturePlot(Epi.cells.nmf,features = "SAA2")
FeaturePlot(Epi.cells.nmf,features = "CCL18")








padj <- 0.05


Epi.cells.diff <- Ciliated.diff

Epi.cells.diff$label <- ifelse(Epi.cells.diff$p_val_adj< padj & abs(Epi.cells.diff$avg_log2FC) >=1,
                               as.character(rownames(Epi.cells.diff)), "")######！设置标签基因范围



Epi.cells.diff$group[(Epi.cells.diff$p_val_adj > 0.05 | Epi.cells.diff$p_val_adj == "NA") | (Epi.cells.diff$avg_log2FC < 0.5) & Epi.cells.diff$avg_log2FC > -0.5] <- "Not"
Epi.cells.diff$group[(Epi.cells.diff$p_val_adj <= 0.05 & Epi.cells.diff$avg_log2FC > 0.5)] <-  "Up"
Epi.cells.diff$group[(Epi.cells.diff$p_val_adj <= 0.05 & Epi.cells.diff$avg_log2FC < -0.5)] <- "Down"


library(ggplot2)
library(ggrepel)

ggplot(Epi.cells.diff, aes(avg_log2FC, -log10(p_val_adj)))+#建立横纵坐标
  geom_point(aes(col=group))+#建造点图
  scale_color_manual(values=c("#0072B5","grey","#BC3C28"))+#改变点颜色
  labs(title = "Ciliated cell")+#加标题备注
  geom_vline(xintercept=c(-0.5,0.5), colour="black", linetype="dashed")+#加线
  geom_hline(yintercept = -log10(0.05),colour="black", linetype="dashed")+
  theme(plot.title = element_text(size = 16, hjust = 0.5, face = "bold"))+
  labs(x="log2(FoldChange)",y="-log10(Pvalue)")+
  theme(axis.text=element_text(size=13),axis.title=element_text(size=13))+
  #str(Epi.cells.diff, max.level = c(-1, 1))+
  theme_classic()+
  geom_label_repel(data = Epi.cells.diff, aes(x = Epi.cells.diff$avg_log2FC, 
                                              y = -log10(Epi.cells.diff$p_val_adj), 
                                              label = label),
                   size = 3, box.padding = unit(0.5, "lines"),
                   point.padding = unit(0.8, "lines"), 
                   segment.color = "black", 
                   show.legend = FALSE)
dev.off()