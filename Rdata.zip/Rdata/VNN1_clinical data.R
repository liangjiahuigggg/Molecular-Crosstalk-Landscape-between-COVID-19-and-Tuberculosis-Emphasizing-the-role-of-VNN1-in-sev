Sys.setenv("VROOM_CONNECTION_SIZE"=131072*6)
library(readxl)
library(tidyverse)
library(GEOquery)
library(tidyverse)
library(limma)

library(ggpubr)



pd <- read.table(file = "GSE157103清洁临床信息.txt",check.names = F)
exp <- read.table(file = "11exp.txt")
exp <- t(exp)
exp <- exp[1:100,]
exp <- as.data.frame(exp)
pd <- pd[1:100,]
#VNN1----
medianScore <- median(exp$VNN1)


score <- exp$VNN1

group=as.vector(ifelse(score>medianScore,"VNN1-high","VNN1-low"))
pd <- mutate(pd,group)
LX <- pd
col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
# col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical-ventilation","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
colnames(LX) <- col
compaired <- list(c("VNN1-low", "VNN1-high"))   #设置比较组别
###连续变量----

#age
age <- LX[,c(1,17)]
age <- na.omit(age)

ggboxplot(age,
          x = "group", y = "age",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")

#APACHE-II
APACHE <- LX[,c(4,17)]
APACHE <- na.omit(APACHE)

ggboxplot(APACHE,
          x = "group", y = "APACHE-II",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")
#charlson-score
charlson <- LX[,c(5,17)]
charlson <- na.omit(charlson)
ggboxplot(charlson,
          x = "group", y = "charlson-score",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")


ggboxplot(ventilator,
          x = "group", y = "ventilator-free-days",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")


#hospital-free days in 45 day
hospital <- LX[,c(9,17)]
hospital <- na.omit(hospital)
ggboxplot(hospital,
          x = "group", y = "hospital-free days in 45 day",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")
#ventilator-free-days
ferritin <- LX[,c(10,17)]
ferritin <- na.omit(ferritin)
ggboxplot(ferritin,
          x = "group", y = "ferritin",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")

#CRP
CRP <- LX[,c(11,17)]
CRP <- na.omit(CRP)
ggboxplot(CRP,
          x = "group", y = "CRP",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")
#DD
DD <- LX[,c(12,17)]
DD <- na.omit(DD)
ggboxplot(DD,
          x = "group", y = "DD",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")
#procalcitonin
procalcitonin <- LX[,c(13,17)]
procalcitonin<- na.omit(procalcitonin)
ggboxplot(procalcitonin,
          x = "group", y = "procalcitonin",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")

#lactate
lactate <- LX[,c(14,17)]
lactate<- na.omit(lactate)
ggboxplot(lactate,
          x = "group", y = "lactate",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")


#fibrinogen
fibrinogen <- LX[,c(15,17)]
fibrinogen<- na.omit(fibrinogen)
ggboxplot(fibrinogen,
          x = "group", y = "fibrinogen",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")

#sofa
sofa <- LX[,c(16,17)]
sofa<- na.omit(sofa)
ggboxplot(sofa,
          x = "group", y = "sofa",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")



#ventilator-free-days
#ventilator <- filter(LX,mechanical==1)
#ventilator <- ventilator[,c(7,17)]
ventilator <- LX[,c(7,17)]
ventilator <- na.omit(ventilator)
colnames(ventilator)[1] <- "ventilator_freedays"
ggboxplot(ventilator,
          x = "group", y = "ventilator_freedays",
          fill = "group", palette = c("#00AFBB", "#E7B800"),
          add = "jitter", size = 0.5)  +  #添加抖动点 +   #添加抖动点
  stat_compare_means(comparisons = compaired,
                     method = "wilcox.test")




####分类变量----
#icu
FL <- arrange(LX,group)

icu <- FL[,c(3,17)]

high <- icu[1:50,]
low <- icu[51:100,]
table(high$icu)
table(low$icu)

k_icu <- data.frame("0"=c(32,18),"1"=c(18,32))
rownames(k_icu) <- c("高风险组","低风险组")
chisq.test(k_icu)

#机械通气
icu <- FL[,c(6,17)]

high <- icu[1:50,]
low <- icu[51:100,]
table(high$mechanical)
table(low$mechanical)

k_icu <- data.frame("0"=c(34,24),"1"=c(16,26))
rownames(k_icu) <- c("高风险组","低风险组")
chisq.test(k_icu)























#GBP4----
medianScore <- median(exp$GBP4)


score <- exp$GBP4

group=as.vector(ifelse(score>medianScore,"GBP4-high","GBP4-low"))
pd <- mutate(pd,group)
LX <- pd
col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
# col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical-ventilation","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
colnames(LX) <- col
compaired <- list(c("GBP4-low", "GBP4-high"))   #设置比较组别






#XAF1----
medianScore <- median(exp$XAF1)


score <- exp$XAF1

group=as.vector(ifelse(score>medianScore,"XAF1-high","XAF1-low"))
pd <- mutate(pd,group)
LX <- pd
col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
# col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical-ventilation","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
colnames(LX) <- col
compaired <- list(c("XAF1-low", "XAF1-high"))   #设置比较组别
#OAS3----
medianScore <- median(exp$OAS3)


score <- exp$OAS3

group=as.vector(ifelse(score>medianScore,"OAS3-high","OAS3-low"))
pd <- mutate(pd,group)
LX <- pd
col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
# col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical-ventilation","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
colnames(LX) <- col
compaired <- list(c("OAS3-low", "OAS3-high"))   #设置比较组别
#RTP4----
medianScore <- median(exp$RTP4)
score <- exp$RTP4
group=as.vector(ifelse(score>medianScore,"RTP4-high","RTP4-low"))
pd <- mutate(pd,group)
LX <- pd
col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
# col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical-ventilation","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
colnames(LX) <- col
compaired <- list(c("RTP4-low", "RTP4-high"))   #设置比较组别
#OAS1----
medianScore <- median(exp$OAS1)
score <- exp$OAS1
group=as.vector(ifelse(score>medianScore,"OAS1-high","OAS1-low"))
pd <- mutate(pd,group)
LX <- pd
col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
# col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical-ventilation","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
colnames(LX) <- col
compaired <- list(c("OAS1-low", "OAS1-high"))   #设置比较组别
#IFI44L----

medianScore <- median(exp$IFI44L)
score <- exp$IFI44L
group=as.vector(ifelse(score>medianScore,"IFI44L-high","IFI44L-low"))
pd <- mutate(pd,group)
LX <- pd
col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
# col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical-ventilation","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
colnames(LX) <- col
compaired <- list(c("ILFI44L-low", "IFI44L-high"))   #设置比较组别










#IFIT1----
medianScore <- median(exp$IFIT1)
score <- exp$RTP4
group=as.vector(ifelse(score>medianScore,"IFIT1-high","IFIT1-low"))
pd <- mutate(pd,group)
LX <- pd
col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
# col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical-ventilation","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
colnames(LX) <- col
compaired <- list(c("IFIT1-low", "IFIT1-high"))   #设置比较组别
#RSAD2----
medianScore <- median(exp$RSAD2)
score <- exp$RSAD2
group=as.vector(ifelse(score>medianScore,"RSAD2-high","RSAD2-low"))
pd <- mutate(pd,group)
LX <- pd
col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
# col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical-ventilation","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
colnames(LX) <- col
compaired <- list(c("RSAD2-low", "RSAD2-high"))   #设置比较组别
#LY6E----
medianScore <- median(exp$LY6E)
score <- exp$LY6E
group=as.vector(ifelse(score>medianScore,"LY6E-high","LY6E-low"))
pd <- mutate(pd,group)
LX <- pd
col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
# col <- c("age","gender","icu","APACHE-II","charlson-score","mechanical-ventilation","ventilator-free-days","DM","hospital-free days in 45 day","ferritin","CRP","DD","procalcitonin","lactate","fibrinogen","sofa","group")
colnames(LX) <- col
compaired <- list(c("LY6E-low", "LY6E-high"))   #设置比较组别









#免疫浸润VNN1----

#VNN1分组
x <- rownames_to_column(LX,"ID")
type <- x[,c(1,18)]
write.table(type,file = "VNN1-type.txt",sep="\t")



















