Sys.setenv("VROOM_CONNECTION_SIZE"=131072*6)
library(readxl)
library(tidyverse)
library(GEOquery)
library(tidyverse)
library(limma)



exp <- read.table(file = "GSE157103_genes.tpm.tsv.gz",sep = "\t")

pd <- read.table(file = "GSE157103注释.txt",sep = "\t")
x <- pd[18,]
x1 <- t(x)  
x1[1] <- "gene"
colnames(exp) <- x1
exp <- column_to_rownames(exp,"gene")
exp <- log2(exp+1)#TPM数据要先log2(x+1)后才能limma
#limma分析https://zhuanlan.zhihu.com/p/437712423
list <- c(rep("COVID19", 100), rep("Control",26)) %>% factor(., levels = c("COVID19", "Control"), ordered = F)
head(list)
list <- model.matrix(~factor(list)+0) 
colnames(list) <- c("COVID19","Control")
df.fit <- lmFit(exp, list)  ## 数据与list进行匹配
df.matrix <- makeContrasts(COVID19 - Control , levels = list)#COVID组比Control组，COVID写前面
fit <- contrasts.fit(df.fit, df.matrix)
fit <- eBayes(fit)
tempOutput <- topTable(fit,n = Inf, adjust = "fdr")
nrDEG = na.omit(tempOutput) ## 去掉数据中有NA的行或列
diffsig <- nrDEG
foldChange = 1
padj = 0.05
## 筛选出所有差异基因的结果
All_diffSig <- diffsig[(diffsig$adj.P.Val < padj & (diffsig$logFC>foldChange | diffsig$logFC < (-foldChange))),]
dim(All_diffSig)
#筛选上下调基因
diffup <-  All_diffSig[(All_diffSig$P.Value < padj & (All_diffSig$logFC > foldChange)),]
write.csv(diffup, "diffup.csv")
#
diffdown <- All_diffSig[(All_diffSig$P.Value < padj & (All_diffSig < -foldChange)),]
diffdown <- na.omit(diffdown)
write.csv(diffdown, "diffdown.csv")



#绘制火山图----
## 导入R包
library(ggplot2)
library(ggrepel)
##  绘制火山图
## 进行分类别
logFC <- diffsig$logFC
deg.padj <- diffsig$adj.P.Val#原文中用的p,这里要改
data <- data.frame(logFC = logFC, padj = deg.padj)
diffsig$group[(diffsig$adj.P.Val > 0.05 | diffsig$adj.P.Val == "NA") | (diffsig$logFC < foldChange) & diffsig$logFC > -foldChange] <- "Not"
diffsig$group[(diffsig$adj.P.Val <= 0.05 & diffsig$logFC > 1)] <-  "Up"
diffsig$group[(diffsig$adj.P.Val <= 0.05 & data$logFC < -1)] <- "Down"
x_lim <- max(logFC,-logFC)

# 开始绘图
pdf('volcano.pdf',width = 7,height = 6.5)  ## 输出文件
diffsig$label <- ifelse(diffsig$adj.P.Val< padj & abs(diffsig$logFC) >=2.5,
       as.character(rownames(diffsig)), "")#设置标签基因范围


ggplot(diffsig, aes(logFC, -log10(adj.P.Val)))+#建立横纵坐标
  geom_point(aes(col=group))+#建造点图
  scale_color_manual(values=c("#0072B5","grey","#BC3C28"))+#改变点颜色
  labs(title = "COVID19")+#加标题备注
  geom_vline(xintercept=c(-1,1), colour="black", linetype="dashed")+#加线
  geom_hline(yintercept = -log10(0.05),colour="black", linetype="dashed")+
  theme(plot.title = element_text(size = 16, hjust = 0.5, face = "bold"))+
  labs(x="log2(FoldChange)",y="-log10(Pvalue)")+
  theme(axis.text=element_text(size=13),axis.title=element_text(size=13))+
  str(diffsig, max.level = c(-1, 1))+theme_bw()+
  geom_label_repel(data = diffsig, aes(x = diffsig$logFC, 
                                       y = -log10(diffsig$adj.P.Val), 
                                       label = label),
                   size = 3, box.padding = unit(0.5, "lines"),
                   point.padding = unit(0.8, "lines"), 
                   segment.color = "black", 
                   show.legend = FALSE)
dev.off()



####诊断ROC----



# gene11 <- c("VNN1","GBP4","XAF1","OAS2","OAS3","RTP4","OAS1","IFI44L","IFIT1","RSAD2","LY6E")
# gene11_exp <- exp[gene11,,drop=F]
# write.table(gene11_exp,file = "11exp.txt",sep = "\t")



