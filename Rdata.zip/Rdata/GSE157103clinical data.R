Sys.setenv("VROOM_CONNECTION_SIZE"=131072*6)
library(readxl)
library(tidyverse)
library(GEOquery)
library(tidyverse)
library(limma)





pd <- read.table(file = "GSE157103注释.txt",sep = "\t")
pd <- as.data.frame(pd)
row <-pd$V1 
rownames(pd) <- row
pd <- pd[,-1]
id <- pd[18,]
id <- t(id)
colnames(pd) <- id
pd <- t(pd)
pd <- as.data.frame(pd)
pd <- pd[,c(2:17)]
pd$age <- stringr::str_sub(pd$age,14,15)
pd$age <- stringr::str_replace(pd$age,":","NA")

pd$gender <- stringr::str_replace(pd$gender,"Sex: female","0" )
pd$gender <- stringr::str_replace(pd$gender,"Sex: male","1" )
pd$gender <- stringr::str_replace(pd$gender,"Sex: unknown","NA" )


pd$icu <- stringr::str_replace(pd$icu,"icu: no","0" )
pd$icu <- stringr::str_replace(pd$icu,"icu: yes","1" )


pd$`APACHE II` <- stringr::str_sub(pd$`APACHE II`,11,20)
pd$`APACHE II` <- stringr::str_replace(pd$`APACHE II`,"unknown","NA" )

pd$`charlson score` <- stringr::str_sub(pd$`charlson score`,16,17)


pd$`mechanical ventilation` <- stringr::str_replace(pd$`mechanical ventilation`,"mechanical ventilation: no","0" )
pd$`mechanical ventilation` <- stringr::str_replace(pd$`mechanical ventilation`,"mechanical ventilation: yes","1" )


pd$`ventilator-free days` <- stringr::str_sub(pd$`ventilator-free days`,22,24)


pd$DM <- stringr::str_replace(pd$DM,"dm: 0","0")
pd$DM <- stringr::str_replace(pd$DM,"dm: 1","1")
pd$DM <- stringr::str_replace(pd$DM,"dm: unknown","NA")

pd$H45 <- stringr::str_sub(pd$H45,48,50)

pd$ferritin <- stringr::str_sub(pd$ferritin,18,50)
pd$ferritin <- stringr::str_replace(pd$ferritin,"unknown","NA")

pd$CRP <- stringr::str_sub(pd$CRP,12,50)
pd$CRP <- stringr::str_replace(pd$CRP,"unknown","NA")

pd$DD <- stringr::str_sub(pd$DD,19,50)
pd$DD <- stringr::str_replace(pd$DD,"unknown","NA")


pd$procalcitonin <- stringr::str_sub(pd$procalcitonin,23,50)
pd$procalcitonin <- stringr::str_replace(pd$procalcitonin,"unknown","NA")

pd$lactate <- stringr::str_sub(pd$lactate,18,50)
pd$lactate <- stringr::str_replace(pd$lactate,"unknown","NA")



pd$fibrinogen <- stringr::str_sub(pd$fibrinogen,12,50)
pd$fibrinogen <- stringr::str_replace(pd$fibrinogen,"unknown","NA")

pd$sofa <- stringr::str_sub(pd$sofa,6,50)
pd$sofa <- stringr::str_replace(pd$sofa,"unknown","NA")

row <- rownames(pd)

pd1 <- as.data.frame(lapply(pd,as.numeric))
rownames(pd1) <- row
write.table(pd1,file = "GSE157103清洁临床信息.txt",sep = "\t")





